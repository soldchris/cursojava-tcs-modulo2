package main;

import com.lab.Busqueda;
import com.lab.Ordenamiento;

public class Main {
    public static void main(String[] args) {
        Ordenamiento ord = new Ordenamiento();
        Busqueda busqueda = new Busqueda();
        int[] numeros = { 50, 20, 40, 80, 30 };
        int clave = 80;
        int[] ordenado;

        System.out.println("----------------------------");
        System.out.println("*** Vector Desordenado ***");
        System.out.println("----------------------------");
        ord.imprimir(numeros);
        System.out.println("----------------------------");
        System.out.println("*** Vector Ordenado ***");
        System.out.println("----------------------------");
        ordenado = ord.insercion(numeros);
        ord.imprimir(ordenado);
        System.out.println("--------------------------------");
        System.out.println("*** Busqueda del Elemento 80 ***");
        System.out.println("--------------------------------");
        busqueda.binaria(ordenado,clave);

        int posicion = busqueda.binaria(ordenado, clave);

        if(posicion == -1) {
            System.out.println("Valor no encontrado");
        }else {
            System.out.println("El valor clave " + clave + " encontrado en la posicion " + posicion );
        }



    }
}
