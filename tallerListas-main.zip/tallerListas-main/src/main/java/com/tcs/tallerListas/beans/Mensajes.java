package com.tcs.tallerListas.beans;

public class Mensajes {
    public final static String INICIO ="################ Ingreso de estudiantes ################";
    public final static String NONUMERICO = "Ha ocurrido un problema al momento de leer la edad, ya que el dato no es númerico!";
    public final static String LECTURA = "Error al momento de leer el archivo";
    public final static String REPETIR = "************** Estudiantes a Repetir **************";
    public final static String TOTAL = "Total Estudiantes registrados: ";
    public final static String RANGO = "Número de estudiantes entre los 6 y los 10 años de edad: ";
    public final static String JARDIN = "************** Estudiantes de Jardin **************";
    public final static String PRIMERO = "************** Estudiantes de Primer Grado **************";
    public final static String SEGUNDO = "************** Estudiantes de Segundo Grado **************";
    public final static String TERCERO = "************** Estudiantes de Tercer Grado **************";
    public final static String CUARTO ="************** Estudiantes de Cuaarto Grado **************";
    public final static String QUINTO = "************** Estudiantes de Quinto Grado **************";
    public final static String ESTUTI = "************** Estudiantes con Id TI **************";
    public final static String RUTA ="src/main/resources/data.txt";
}
