package com.capacitacion.excepciones;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;

import com.capacitacion.excepciones.personalizadas.MisExcepciones;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.capacitacion.excepciones.procesos.ProcesarDatos;

@SpringBootApplication
public class ExcepcionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcepcionesApplication.class, args);

		//caso1();
		//caso2();
		//caso3();
		//caso4();
		caso5();

	}
	
	
	public static void caso1() {
		ProcesarDatos proceso = new ProcesarDatos();
		int resultado = 0;
		try {
			resultado = proceso.division("15,8", "30");
		}catch (ArithmeticException e){
			System.out.println("Detalle del error: " + e.getMessage() + "; " + e.getCause());
			e.printStackTrace();
		}catch (NumberFormatException e){
			System.out.println("Detalle del error: " + e.getMessage() + "; " + e.getCause());
			e.printStackTrace();
		}


		
	}
	public static void caso2() {
		ProcesarDatos proceso = new ProcesarDatos();
		String [] lista = {"1","2","3"};
		try {
			proceso.arreglo(lista);
		}catch (ArrayIndexOutOfBoundsException e){
			System.out.println("Detalle del error: " + e.getMessage() + "; " + e.getCause());
			e.printStackTrace();
		}


		
	}
	
	public static void caso3() {
		ProcesarDatos proceso = new ProcesarDatos();
		try {
			proceso.fecha("1985/04/28");
		} catch (ParseException e) {
			System.out.println("Detalle del error: " + e.getMessage() + "; " + e.getCause());
			e.printStackTrace();
		}

	}

	public static void caso4() {
		ProcesarDatos proceso = new ProcesarDatos();
		try {
			proceso.archivo("src/main/java/com/capacitacion/excepciones/datos/data.txt");
		} catch (MisExcepciones misExcepciones) {
			System.out.println(misExcepciones.getCausa() + " " + misExcepciones.getTipoFalla());
		}
	}
	
	public static void caso5() {
		ProcesarDatos proceso = new ProcesarDatos();
		try {
			proceso.leerArchivo("src/main/java/com/capacitacion/excepciones/datos/data.txt","src/main/java/com/capacitacion/excepciones/datos/data2.txt");
		} catch (MisExcepciones misExcepciones) {
			System.out.println(misExcepciones.getCausa() + " " + misExcepciones.getTipoFalla());
		}


	}
	

}
