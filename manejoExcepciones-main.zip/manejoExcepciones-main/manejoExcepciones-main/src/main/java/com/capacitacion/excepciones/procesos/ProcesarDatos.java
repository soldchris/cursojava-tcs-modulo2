package com.capacitacion.excepciones.procesos;

import com.capacitacion.excepciones.personalizadas.MisExcepciones;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class ProcesarDatos {


	public int division(String numero1,String numero2) {
		int resultado = 0;
		
		resultado=Integer.valueOf(numero1)/Integer.valueOf(numero2);
		return resultado;
		
	}
	
	
	public void arreglo(String[] lista) {

			for(int i=0;i<=5;i++) {
				System.out.println(lista[i]);
			}

	}
	
	public void fecha(String input) throws ParseException{
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date   date  = format.parse (input );
			date.toString();
	}

	public void archivo(String ruta) throws MisExcepciones {
		Scanner data = null;
		try {
			data = new Scanner(new File(ruta));
		} catch (FileNotFoundException e) {
			throw new MisExcepciones("No Se pudo acceder a la ruta",e.getMessage());
		}finally {
			if (data != null){
				data.close();
			}
		}
	}


	public void leerArchivo(String ruta, String ruta2) throws MisExcepciones{
		FileWriter data2 = null;
		Scanner data = null;
		String[] estData = null;
		try {
			data = new Scanner(new File(ruta));
			data2 = new FileWriter(ruta2);

			while (data.hasNextLine()){
				estData = data.nextLine().split(";");
				data2.write(estData[0] + " " + estData[estData.length - 1]+ "\n");
			}

		} catch (FileNotFoundException e) {
			throw new MisExcepciones("No Se pudo acceder a la ruta",e.getMessage());
		} catch (IOException e) {
			throw new MisExcepciones("No Se pudo acceder a la ruta",e.getMessage());
		} finally {
			if (data != null){
				data.close();
				try {
					data2.close();
				} catch (IOException e) {
					throw new MisExcepciones("No Se pudo cerrar el fichero",e.getMessage());
				}
			}
		}
	}


}
